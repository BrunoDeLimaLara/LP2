﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmatriz
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["Form2"];
            if (fc != null)
                fc.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string ra;
            string[] outroVetor = new string[10];
            string aux1;
            int i, j, N, numCaracteres;

            lstNomes.Items.Clear();

            ra = Interaction.InputBox("Digite o último dígito do seu RA: ", "Entrada de Dados");

            if (Int32.TryParse(ra, out N))
            {

                if (N <= 0 || N > 10)
                    N = 10;
                

                for (i = 0; i < N; i++)
                {
                    numCaracteres = 0;

                    aux1 = Interaction.InputBox("Informe o Nome ", "Entrada de Dados ");

                    for (j = 0; j < aux1.Length; j++)
                    {
                        if (Char.IsLetter(aux1[j]))
                        {
                            numCaracteres += 1;
                        }
                    }

                    outroVetor[i] = "O Nome: " + aux1 + " Têm: " + Convert.ToString(numCaracteres) + " Caracteres";
                   
                }

                for (i = 0; i < N; i++) 
                {
                    lstNomes.Items.Add(outroVetor[i] + "\n");
                }
            }
            else 
            {
                MessageBox.Show("RA Inválido!");
            }
        }

        private void lstNomes_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
