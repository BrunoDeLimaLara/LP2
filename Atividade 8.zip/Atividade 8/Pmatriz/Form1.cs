﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace Pmatriz
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string aux;

            for (var i = 0; i < 20; i++)
            {
                aux = Interaction.InputBox("Digite o número", "Entrada de dados");

                if (!Int32.TryParse(aux, out vetor[i])) 
                {
                    MessageBox.Show("Dados Inválidos!");
                    i--;
                }
            }

            aux = ""; 

            for (var i = 19; i >= 0; i--) 
            {
                aux = aux + vetor[i] + "\n";
            }

            MessageBox.Show(aux);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string auxiliar = "";
            double[] qtd = new double[10];
            double[] vlr = new double[10];
            double faturamento = 0;

            for (var i = 0; i < 10; i++) 
            {
                auxiliar = Interaction.InputBox("Digite a quantidade da Mercadoria" + (i + 1), "Entrada de Quantidades");

                if (!double.TryParse(auxiliar, out qtd[i])) 
                {
                    MessageBox.Show("Quantidade inválida!");
                    i--;
                }
                else 
                {
                    while (vlr[i] <= 0) 
                    {
                        auxiliar = "";
                        auxiliar = Interaction.InputBox("Digite o Valor da Mercadoria " + (i + 1), "Entrada de Preços");

                        if (!double.TryParse(auxiliar, out vlr[i])) 
                        {
                            MessageBox.Show("Preço Inválido!");
                        }
                    }

                    faturamento += qtd[i] * vlr[i]; 
                }             
            }
            MessageBox.Show(faturamento.ToString("N2"));
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string[] Alunos = {"Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby"};
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;

            for (I = 0; I < N; I++)
            {
                Total += Alunos[I].Length;
                MessageBox.Show(Convert.ToString(Total));
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int i;
            string[] ArrayList = { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" };
            string Stringao = "";

            for (i = 0; i < ArrayList.Length; i++) 
            {
                if (ArrayList[i] == "Otávio") 
                {
                    ArrayList[i] = "";
                }
            }

            for (i = 0; i < ArrayList.Length; i++) 
            {
                if (ArrayList[i] != "") 
                {
                    Stringao += ArrayList[i] + "\n";
                }              
            }

            MessageBox.Show(Stringao);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            double media;
            double[,] notas = new double[20, 3];
            string auxiliar;

            for (var i = 0; i < 20; i++)
            {
                media = 0;

                for (var j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox("Digite a nota " + (j + 1) + " do aluno " + (i + 1), "Entrada de Dados");

                    if (!double.TryParse(auxiliar, out notas[i, j]))
                    {
                        MessageBox.Show("Nota Inválida!");
                        j--;
                    }
                    else
                    {
                        if (notas[i, j] < 0 || notas[i, j] > 10)
                        {
                            MessageBox.Show("Nota Inválida!");
                            j--;
                        }
                        else 
                        {
                            media += notas[i, j];
                        }                                 
                    }                 
                }

                media = media / 3;

                MessageBox.Show("Aluno: " + (i + 1) + " Média: " + media.ToString("N2"));
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["Form2"];
            if (fc != null)
                fc.Close();

            Form2 Form2 = new Form2();
            Form2.Show();
        }
    }
}
