﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pvolume
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double raio, altura;

            if(Double.TryParse(txtAltura.Text, out altura) &&
               Double.TryParse(txtRaio.Text, out raio))
            {
                if ((altura <= 0) || (raio <= 0)) 
                {
                        MessageBox.Show("altura e raio devem ser maior que zero");
                       txtRaio.Focus();
                }
 
                else
               {
                double volume;

                 //volume = 3.14 * raio* raio * altura;
                 volume = Math.PI * Math.Pow(raio, 2) * altura;
                 txtVolume.Text = volume.ToString("N2");
               }
            }
            // valores inseridos não são números
            else
            {MessageBox.Show("valores inválidos!");
            txtRaio.Focus();
                            //propriedades "enable" == False  ou  readonly = true
                            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            //limpar os dados são as maneiras de de deixar limpa
            txtAltura.Clear();
            txtRaio.Text = "";
            txtVolume.Text = string.Empty;

            txtRaio.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtRaio_TextChanged(object sender, EventArgs e)
        {

        }
    }

}
