﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        double Numero1, Numero2, Resultado;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnSubtracao_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(txtNumero1.Text) || String.IsNullOrEmpty(txtNumero2.Text))
            {
                MessageBox.Show("Por favor, preencha todos os número primeiro");
            }
            else
            {
                if(Double.TryParse(txtNumero1.Text, out Numero1) && (Double.TryParse(txtNumero2.Text, out Numero2)))
                {
                    Resultado = Numero1 - Numero2;
                    txtResultado.Text = Resultado.ToString();
                }
                else
                {
                    MessageBox.Show("Valores Iválidos");
                }
            }
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            if(String.IsNullOrEmpty(txtNumero1.Text)|| (String.IsNullOrEmpty(txtNumero2.Text)))
            {
                MessageBox.Show("Por favor, preencha todos os número primeiro");
            }
            else
            {
                if(Double.TryParse(txtNumero1.Text, out Numero1) && (Double.TryParse(txtNumero2.Text, out Numero2)))
                {
                    if (Numero2 == 0)
                    {
                        MessageBox.Show("Não é possivel dividir por Zero.");
                    }
                    else
                    {
                        Resultado = Numero1 / Numero2;
                        txtResultado.Text = Resultado.ToString();
                    }
                }
                else
                {
                    MessageBox.Show(" Valores Invalidos");
                }
            }
        }

        private void btnMultiplicacao_Click(object sender, EventArgs e)
        {
            if(String.IsNullOrEmpty(txtNumero1.Text) || String.IsNullOrEmpty(txtNumero2.Text))
            {
                MessageBox.Show("Por favor, preencha todos os numeros primeiro");
            }
            else
            {
                if (Double.TryParse(txtNumero1.Text, out Numero1) && (Double.TryParse(txtNumero2.Text, out Numero2)))
                {
                    Resultado = Numero1 * Numero2;
                    txtResultado.Text = Resultado.ToString();
                }
                else
                {
                    MessageBox.Show("Valores Invalidos");
                }
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Text = string.Empty;
            txtNumero2.Text = string.Empty;
            txtResultado.Text = string.Empty;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txtNumero1.Text) || String.IsNullOrEmpty(txtNumero2.Text))
            {
                MessageBox.Show("Por favor, preencha todos os número primeiro");
            }
            else
            {
                if(Double.TryParse(txtNumero1.Text, out Numero1) && (Double.TryParse(txtNumero2.Text, out Numero2)))
                {
                    Resultado = Numero1 + Numero2;
                    txtResultado.Text = Resultado.ToString();
                }
                else
                {
                    MessageBox.Show("Valores Ivalidos");
                }
            }
        }



        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (Char)13)
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }
    }
}
