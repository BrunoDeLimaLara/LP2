﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnValidarDesconto_Click(object sender, EventArgs e)
        {

            double descontoINSS = 0;
            double descontoIRPF = 0;
            double salarioLiquido = 0;
            double salarioBruto = 0;
            double salarioFamilia = 0;
            double numeroFilhos = 0;

            if (txtNome.Text == String.Empty)
                MessageBox.Show("Informe o nome primeiro!");
            else
            {
                if (Double.TryParse(mskbxSalarioBruto.Text, out salarioBruto))
                {
                    numeroFilhos = Convert.ToDouble(nupdFilhos.Value);

                    if (salarioBruto <= 0)
                    {
                        MessageBox.Show("O salário precisa ser maior do que zero!");
                    }
                    else
                    {
                        //Aliquota INSS para Salário Bruto:
                        if (salarioBruto <= 800.47)
                        {
                            mskbxAliquotaINSS.Text = "7,65%";
                            descontoINSS = 0.0765 * salarioBruto;
                            mskbxDescontoINSS.Text = Convert.ToString(descontoINSS);
                        }
                        else if (salarioBruto <= 1050)
                        {
                            mskbxAliquotaINSS.Text = "8,65%";
                            descontoINSS = 0.0865 * salarioBruto;
                            mskbxDescontoINSS.Text = Convert.ToString(descontoINSS);
                        }
                        else if (salarioBruto <= 1400.77)
                        {
                            mskbxAliquotaINSS.Text = "9,00%";
                            descontoINSS = 0.09 * salarioBruto;
                            mskbxDescontoINSS.Text = Convert.ToString(descontoINSS);
                        }
                        else if (salarioBruto <= 2801.56)
                        {
                            mskbxAliquotaINSS.Text = "11,00%";
                            descontoINSS = 0.11 * salarioBruto;
                            mskbxDescontoINSS.Text = Convert.ToString(descontoINSS);
                        }
                        else
                        {
                            mskbxAliquotaINSS.Text = "308.17";
                            descontoINSS = salarioBruto - 308.17;
                            mskbxDescontoINSS.Text = Convert.ToString(descontoINSS);
                        }

                        //Alíquota IRPF para Salário Bruto:
                        if (salarioBruto <= 1257.12)
                        {
                            mskbxAliquotaIRPF.Text = "0,00%";
                            descontoIRPF = 0;
                            mskbxDescontoIRPF.Text = Convert.ToString(descontoIRPF);
                        }
                        else if (salarioBruto <= 2512.08)
                        {
                            mskbxAliquotaIRPF.Text = "15,00%";
                            descontoIRPF = salarioBruto * 0.15;
                            mskbxDescontoIRPF.Text = Convert.ToString(descontoIRPF);
                        }
                        else
                        {
                            mskbxAliquotaIRPF.Text = "27,50%";
                            descontoIRPF = salarioBruto * 0.2750;
                            mskbxDescontoIRPF.Text = Convert.ToString(descontoIRPF);
                        }

                        //Salário Família para Salário Bruto:
                        if (salarioBruto <= 435.52)
                        {
                            salarioFamilia = numeroFilhos * 22.33;
                            mskbxSalarioFamilia.Text = salarioFamilia.ToString();
                        }
                        else if (salarioBruto <= 654.61)
                        {
                            salarioFamilia = numeroFilhos * 15.74;
                            mskbxSalarioFamilia.Text = salarioFamilia.ToString();
                        }
                        else
                        {
                            salarioFamilia = 0;
                            mskbxSalarioFamilia.Text = salarioFamilia.ToString();
                        }

                        //Cálculo Salário Líqudo
                        salarioLiquido = salarioBruto - descontoINSS - descontoIRPF + salarioFamilia;
                        mskbxSalarioLiquido.Text = Convert.ToString(salarioLiquido);

                        lblDados.Visible = true;

                        if (rbtnF.Checked is true)
                        {
                            if (checkBox1.Checked is true)
                            {
                                lblDados.Text = "Os descontos do salário da senhorita " + txtNome.Text + " que é casada e tem " + Convert.ToString(numeroFilhos) + " filho(s).";
                            }
                            else
                            {
                                lblDados.Text = "Os descontos do salário da senhorita " + txtNome.Text + " e tem " + Convert.ToString(numeroFilhos) + " filho(s).";
                            }
                        }
                        else
                        {
                            if (checkBox1.Checked is true)
                            {
                                lblDados.Text = "Os descontos do salário do senhor " + txtNome.Text + " que é casado e tem " + Convert.ToString(numeroFilhos) + " filho(s).";
                            }
                            else
                            {
                                lblDados.Text = "Os descontos do salário do senhor " + txtNome.Text + " e tem " + Convert.ToString(numeroFilhos) + " filho(s).";
                            }
                        }
                    }

                }
                else 
                {
                    MessageBox.Show("Valores Inválidos!");
                }
            }
        }
    }
}
