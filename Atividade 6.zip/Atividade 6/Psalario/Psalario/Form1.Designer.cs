﻿namespace Psalario
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbxGenero = new System.Windows.Forms.GroupBox();
            this.rbtnM = new System.Windows.Forms.RadioButton();
            this.rbtnF = new System.Windows.Forms.RadioButton();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalarioBruto = new System.Windows.Forms.Label();
            this.lblFilhos = new System.Windows.Forms.Label();
            this.lblAliquotaINSS = new System.Windows.Forms.Label();
            this.lblAliquotaIRPF = new System.Windows.Forms.Label();
            this.lblSalarioFamilia = new System.Windows.Forms.Label();
            this.lblSalarioLiquido = new System.Windows.Forms.Label();
            this.lblDescontoINSS = new System.Windows.Forms.Label();
            this.lblDescontoIRPF = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.nupdFilhos = new System.Windows.Forms.NumericUpDown();
            this.pnlCasado = new System.Windows.Forms.Panel();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.btnValidarDesconto = new System.Windows.Forms.Button();
            this.lblDados = new System.Windows.Forms.Label();
            this.mskbxSalarioBruto = new System.Windows.Forms.MaskedTextBox();
            this.mskbxAliquotaINSS = new System.Windows.Forms.MaskedTextBox();
            this.mskbxAliquotaIRPF = new System.Windows.Forms.MaskedTextBox();
            this.mskbxSalarioFamilia = new System.Windows.Forms.MaskedTextBox();
            this.mskbxSalarioLiquido = new System.Windows.Forms.MaskedTextBox();
            this.mskbxDescontoINSS = new System.Windows.Forms.MaskedTextBox();
            this.mskbxDescontoIRPF = new System.Windows.Forms.MaskedTextBox();
            this.cbxGenero.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nupdFilhos)).BeginInit();
            this.pnlCasado.SuspendLayout();
            this.SuspendLayout();
            // 
            // cbxGenero
            // 
            this.cbxGenero.Controls.Add(this.rbtnM);
            this.cbxGenero.Controls.Add(this.rbtnF);
            this.cbxGenero.Location = new System.Drawing.Point(336, 47);
            this.cbxGenero.Name = "cbxGenero";
            this.cbxGenero.Size = new System.Drawing.Size(249, 89);
            this.cbxGenero.TabIndex = 0;
            this.cbxGenero.TabStop = false;
            this.cbxGenero.Text = "Sexo";
            // 
            // rbtnM
            // 
            this.rbtnM.AutoSize = true;
            this.rbtnM.Location = new System.Drawing.Point(22, 60);
            this.rbtnM.Name = "rbtnM";
            this.rbtnM.Size = new System.Drawing.Size(34, 17);
            this.rbtnM.TabIndex = 1;
            this.rbtnM.TabStop = true;
            this.rbtnM.Text = "M";
            this.rbtnM.UseVisualStyleBackColor = true;
            // 
            // rbtnF
            // 
            this.rbtnF.AutoSize = true;
            this.rbtnF.Location = new System.Drawing.Point(22, 37);
            this.rbtnF.Name = "rbtnF";
            this.rbtnF.Size = new System.Drawing.Size(31, 17);
            this.rbtnF.TabIndex = 0;
            this.rbtnF.TabStop = true;
            this.rbtnF.Text = "F";
            this.rbtnF.UseVisualStyleBackColor = true;
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(12, 47);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(93, 13);
            this.lblNome.TabIndex = 1;
            this.lblNome.Text = "Nome Funcionário";
            // 
            // lblSalarioBruto
            // 
            this.lblSalarioBruto.AutoSize = true;
            this.lblSalarioBruto.Location = new System.Drawing.Point(12, 84);
            this.lblSalarioBruto.Name = "lblSalarioBruto";
            this.lblSalarioBruto.Size = new System.Drawing.Size(67, 13);
            this.lblSalarioBruto.TabIndex = 2;
            this.lblSalarioBruto.Text = "Salário Bruto";
            // 
            // lblFilhos
            // 
            this.lblFilhos.AutoSize = true;
            this.lblFilhos.Location = new System.Drawing.Point(12, 118);
            this.lblFilhos.Name = "lblFilhos";
            this.lblFilhos.Size = new System.Drawing.Size(89, 13);
            this.lblFilhos.TabIndex = 3;
            this.lblFilhos.Text = "Número de Filhos";
            // 
            // lblAliquotaINSS
            // 
            this.lblAliquotaINSS.AutoSize = true;
            this.lblAliquotaINSS.Location = new System.Drawing.Point(13, 276);
            this.lblAliquotaINSS.Name = "lblAliquotaINSS";
            this.lblAliquotaINSS.Size = new System.Drawing.Size(73, 13);
            this.lblAliquotaINSS.TabIndex = 4;
            this.lblAliquotaINSS.Text = "Aliquota INSS";
            // 
            // lblAliquotaIRPF
            // 
            this.lblAliquotaIRPF.AutoSize = true;
            this.lblAliquotaIRPF.Location = new System.Drawing.Point(11, 312);
            this.lblAliquotaIRPF.Name = "lblAliquotaIRPF";
            this.lblAliquotaIRPF.Size = new System.Drawing.Size(72, 13);
            this.lblAliquotaIRPF.TabIndex = 5;
            this.lblAliquotaIRPF.Text = "Aliquota IRPF";
            // 
            // lblSalarioFamilia
            // 
            this.lblSalarioFamilia.AutoSize = true;
            this.lblSalarioFamilia.Location = new System.Drawing.Point(10, 348);
            this.lblSalarioFamilia.Name = "lblSalarioFamilia";
            this.lblSalarioFamilia.Size = new System.Drawing.Size(76, 13);
            this.lblSalarioFamilia.TabIndex = 6;
            this.lblSalarioFamilia.Text = "Salário Família";
            // 
            // lblSalarioLiquido
            // 
            this.lblSalarioLiquido.AutoSize = true;
            this.lblSalarioLiquido.Location = new System.Drawing.Point(8, 381);
            this.lblSalarioLiquido.Name = "lblSalarioLiquido";
            this.lblSalarioLiquido.Size = new System.Drawing.Size(78, 13);
            this.lblSalarioLiquido.TabIndex = 7;
            this.lblSalarioLiquido.Text = "Salário Líquido";
            // 
            // lblDescontoINSS
            // 
            this.lblDescontoINSS.AutoSize = true;
            this.lblDescontoINSS.Location = new System.Drawing.Point(307, 312);
            this.lblDescontoINSS.Name = "lblDescontoINSS";
            this.lblDescontoINSS.Size = new System.Drawing.Size(81, 13);
            this.lblDescontoINSS.TabIndex = 8;
            this.lblDescontoINSS.Text = "Desconto INSS";
            // 
            // lblDescontoIRPF
            // 
            this.lblDescontoIRPF.AutoSize = true;
            this.lblDescontoIRPF.Location = new System.Drawing.Point(308, 276);
            this.lblDescontoIRPF.Name = "lblDescontoIRPF";
            this.lblDescontoIRPF.Size = new System.Drawing.Size(80, 13);
            this.lblDescontoIRPF.TabIndex = 9;
            this.lblDescontoIRPF.Text = "Desconto IRPF";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(111, 47);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(166, 20);
            this.txtNome.TabIndex = 10;
            // 
            // nupdFilhos
            // 
            this.nupdFilhos.Location = new System.Drawing.Point(111, 116);
            this.nupdFilhos.Name = "nupdFilhos";
            this.nupdFilhos.Size = new System.Drawing.Size(166, 20);
            this.nupdFilhos.TabIndex = 19;
            // 
            // pnlCasado
            // 
            this.pnlCasado.Controls.Add(this.checkBox1);
            this.pnlCasado.Location = new System.Drawing.Point(336, 163);
            this.pnlCasado.Name = "pnlCasado";
            this.pnlCasado.Size = new System.Drawing.Size(249, 42);
            this.pnlCasado.TabIndex = 20;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(22, 14);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(62, 17);
            this.checkBox1.TabIndex = 0;
            this.checkBox1.Text = "Casado";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // btnValidarDesconto
            // 
            this.btnValidarDesconto.Location = new System.Drawing.Point(134, 163);
            this.btnValidarDesconto.Name = "btnValidarDesconto";
            this.btnValidarDesconto.Size = new System.Drawing.Size(125, 42);
            this.btnValidarDesconto.TabIndex = 21;
            this.btnValidarDesconto.Text = "Verifica Desconto";
            this.btnValidarDesconto.UseVisualStyleBackColor = true;
            this.btnValidarDesconto.Click += new System.EventHandler(this.btnValidarDesconto_Click);
            // 
            // lblDados
            // 
            this.lblDados.AutoSize = true;
            this.lblDados.Location = new System.Drawing.Point(15, 231);
            this.lblDados.Name = "lblDados";
            this.lblDados.Size = new System.Drawing.Size(48, 13);
            this.lblDados.TabIndex = 22;
            this.lblDados.Text = "lblDados";
            this.lblDados.Visible = false;
            // 
            // mskbxSalarioBruto
            // 
            this.mskbxSalarioBruto.Location = new System.Drawing.Point(111, 81);
            this.mskbxSalarioBruto.Mask = "0000.00";
            this.mskbxSalarioBruto.Name = "mskbxSalarioBruto";
            this.mskbxSalarioBruto.Size = new System.Drawing.Size(166, 20);
            this.mskbxSalarioBruto.TabIndex = 23;
            // 
            // mskbxAliquotaINSS
            // 
            this.mskbxAliquotaINSS.Enabled = false;
            this.mskbxAliquotaINSS.Location = new System.Drawing.Point(88, 273);
            this.mskbxAliquotaINSS.Name = "mskbxAliquotaINSS";
            this.mskbxAliquotaINSS.Size = new System.Drawing.Size(166, 20);
            this.mskbxAliquotaINSS.TabIndex = 24;
            // 
            // mskbxAliquotaIRPF
            // 
            this.mskbxAliquotaIRPF.Enabled = false;
            this.mskbxAliquotaIRPF.Location = new System.Drawing.Point(87, 309);
            this.mskbxAliquotaIRPF.Name = "mskbxAliquotaIRPF";
            this.mskbxAliquotaIRPF.Size = new System.Drawing.Size(165, 20);
            this.mskbxAliquotaIRPF.TabIndex = 25;
            // 
            // mskbxSalarioFamilia
            // 
            this.mskbxSalarioFamilia.Enabled = false;
            this.mskbxSalarioFamilia.Location = new System.Drawing.Point(88, 345);
            this.mskbxSalarioFamilia.Name = "mskbxSalarioFamilia";
            this.mskbxSalarioFamilia.Size = new System.Drawing.Size(164, 20);
            this.mskbxSalarioFamilia.TabIndex = 26;
            // 
            // mskbxSalarioLiquido
            // 
            this.mskbxSalarioLiquido.Enabled = false;
            this.mskbxSalarioLiquido.Location = new System.Drawing.Point(87, 378);
            this.mskbxSalarioLiquido.Name = "mskbxSalarioLiquido";
            this.mskbxSalarioLiquido.Size = new System.Drawing.Size(165, 20);
            this.mskbxSalarioLiquido.TabIndex = 27;
            // 
            // mskbxDescontoINSS
            // 
            this.mskbxDescontoINSS.Enabled = false;
            this.mskbxDescontoINSS.Location = new System.Drawing.Point(395, 309);
            this.mskbxDescontoINSS.Name = "mskbxDescontoINSS";
            this.mskbxDescontoINSS.Size = new System.Drawing.Size(166, 20);
            this.mskbxDescontoINSS.TabIndex = 28;
            // 
            // mskbxDescontoIRPF
            // 
            this.mskbxDescontoIRPF.Enabled = false;
            this.mskbxDescontoIRPF.Location = new System.Drawing.Point(394, 273);
            this.mskbxDescontoIRPF.Name = "mskbxDescontoIRPF";
            this.mskbxDescontoIRPF.Size = new System.Drawing.Size(167, 20);
            this.mskbxDescontoIRPF.TabIndex = 29;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(658, 474);
            this.Controls.Add(this.mskbxDescontoIRPF);
            this.Controls.Add(this.mskbxDescontoINSS);
            this.Controls.Add(this.mskbxSalarioLiquido);
            this.Controls.Add(this.mskbxSalarioFamilia);
            this.Controls.Add(this.mskbxAliquotaIRPF);
            this.Controls.Add(this.mskbxAliquotaINSS);
            this.Controls.Add(this.mskbxSalarioBruto);
            this.Controls.Add(this.lblDados);
            this.Controls.Add(this.btnValidarDesconto);
            this.Controls.Add(this.pnlCasado);
            this.Controls.Add(this.nupdFilhos);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblDescontoIRPF);
            this.Controls.Add(this.lblDescontoINSS);
            this.Controls.Add(this.lblSalarioLiquido);
            this.Controls.Add(this.lblSalarioFamilia);
            this.Controls.Add(this.lblAliquotaIRPF);
            this.Controls.Add(this.lblAliquotaINSS);
            this.Controls.Add(this.lblFilhos);
            this.Controls.Add(this.lblSalarioBruto);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.cbxGenero);
            this.Name = "Form1";
            this.Text = "Salário Funcionário";
            this.cbxGenero.ResumeLayout(false);
            this.cbxGenero.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nupdFilhos)).EndInit();
            this.pnlCasado.ResumeLayout(false);
            this.pnlCasado.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox cbxGenero;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalarioBruto;
        private System.Windows.Forms.Label lblFilhos;
        private System.Windows.Forms.Label lblAliquotaINSS;
        private System.Windows.Forms.Label lblAliquotaIRPF;
        private System.Windows.Forms.Label lblSalarioFamilia;
        private System.Windows.Forms.Label lblSalarioLiquido;
        private System.Windows.Forms.Label lblDescontoINSS;
        private System.Windows.Forms.Label lblDescontoIRPF;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.NumericUpDown nupdFilhos;
        private System.Windows.Forms.Panel pnlCasado;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.RadioButton rbtnM;
        private System.Windows.Forms.RadioButton rbtnF;
        private System.Windows.Forms.Button btnValidarDesconto;
        private System.Windows.Forms.Label lblDados;
        private System.Windows.Forms.MaskedTextBox mskbxSalarioBruto;
        private System.Windows.Forms.MaskedTextBox mskbxAliquotaINSS;
        private System.Windows.Forms.MaskedTextBox mskbxAliquotaIRPF;
        private System.Windows.Forms.MaskedTextBox mskbxSalarioFamilia;
        private System.Windows.Forms.MaskedTextBox mskbxSalarioLiquido;
        private System.Windows.Forms.MaskedTextBox mskbxDescontoINSS;
        private System.Windows.Forms.MaskedTextBox mskbxDescontoIRPF;
    }
}

