﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Text = "";
            txtResultado.Text = string.Empty;  
        }

        private void txtResultado_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnadicao_Click(object sender, EventArgs e)
        {
            double Soma;
            Soma = float.Parse(txtNumero1.Text) + float.Parse(txtNumero2.Text);
            txtResultado.Text = Soma.ToString("N2");
        }

        private void btnSubtracao_Click(object sender, EventArgs e)
        {
            double Subtracao;
            Subtracao = float.Parse(txtNumero1.Text) - float.Parse(txtNumero2.Text);
            txtResultado.Text = Subtracao.ToString("N2");
        }

        private void btnMultiplic_Click(object sender, EventArgs e)
        {
            double Multiplicacao;
            Multiplicacao = float.Parse(txtNumero1.Text) * float.Parse(txtNumero2.Text);
            txtResultado.Text = Multiplicacao.ToString("N2");
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
          //  double Numero1, Numero2;
           // if(Double.TryParse(txtNumero1, out Numero1) &&
           //     Double.TryParse(txtNumero2, out Numero2))

            double Divisao, Numero1, Numero2;
            Double.TryParse(txtNumero1.Text, out Numero1);
            Double.TryParse(txtNumero2.Text, out Numero2);

            Divisao = Numero1 / Numero2;
            txtResultado.Text = Divisao.ToString("N2");
            //Divsao = float.Parse(txtNumero1.Text) / float.Parse(txtNumero2.Text);
            //txtResultado.Text = Divisao.ToString("N2");
        }
    }
}
