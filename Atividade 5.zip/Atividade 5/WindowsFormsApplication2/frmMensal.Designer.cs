﻿namespace WindowsFormsApplication2
{
    partial class frmMensal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GbxHomeOffice = new System.Windows.Forms.GroupBox();
            this.Rbtnao = new System.Windows.Forms.RadioButton();
            this.RbtSim = new System.Windows.Forms.RadioButton();
            this.BtnInstanciar2 = new System.Windows.Forms.Button();
            this.BtnInstanciar1 = new System.Windows.Forms.Button();
            this.lblEntradaEmpresa = new System.Windows.Forms.Label();
            this.LblSalarioMensal = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.LblMatricula = new System.Windows.Forms.Label();
            this.txtData = new System.Windows.Forms.TextBox();
            this.txtSalarioMensal = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.GbxHomeOffice.SuspendLayout();
            this.SuspendLayout();
            // 
            // GbxHomeOffice
            // 
            this.GbxHomeOffice.Controls.Add(this.Rbtnao);
            this.GbxHomeOffice.Controls.Add(this.RbtSim);
            this.GbxHomeOffice.Location = new System.Drawing.Point(689, 127);
            this.GbxHomeOffice.Name = "GbxHomeOffice";
            this.GbxHomeOffice.Size = new System.Drawing.Size(200, 100);
            this.GbxHomeOffice.TabIndex = 21;
            this.GbxHomeOffice.TabStop = false;
            this.GbxHomeOffice.Text = "Trabalha em Home Office";
            this.GbxHomeOffice.Enter += new System.EventHandler(this.GbxHomeOffice_Enter);
            // 
            // Rbtnao
            // 
            this.Rbtnao.AutoSize = true;
            this.Rbtnao.Location = new System.Drawing.Point(6, 39);
            this.Rbtnao.Name = "Rbtnao";
            this.Rbtnao.Size = new System.Drawing.Size(45, 17);
            this.Rbtnao.TabIndex = 1;
            this.Rbtnao.TabStop = true;
            this.Rbtnao.Text = "Não";
            this.Rbtnao.UseVisualStyleBackColor = true;
            // 
            // RbtSim
            // 
            this.RbtSim.AutoSize = true;
            this.RbtSim.Location = new System.Drawing.Point(6, 19);
            this.RbtSim.Name = "RbtSim";
            this.RbtSim.Size = new System.Drawing.Size(42, 17);
            this.RbtSim.TabIndex = 0;
            this.RbtSim.TabStop = true;
            this.RbtSim.Text = "Sim";
            this.RbtSim.UseVisualStyleBackColor = true;
            // 
            // BtnInstanciar2
            // 
            this.BtnInstanciar2.Location = new System.Drawing.Point(488, 368);
            this.BtnInstanciar2.Name = "BtnInstanciar2";
            this.BtnInstanciar2.Size = new System.Drawing.Size(272, 109);
            this.BtnInstanciar2.TabIndex = 20;
            this.BtnInstanciar2.Text = "Instanciar Mensalista passando parâmentros";
            this.BtnInstanciar2.UseVisualStyleBackColor = true;
            this.BtnInstanciar2.Click += new System.EventHandler(this.BtnInstanciar2_Click);
            // 
            // BtnInstanciar1
            // 
            this.BtnInstanciar1.Location = new System.Drawing.Point(194, 368);
            this.BtnInstanciar1.Name = "BtnInstanciar1";
            this.BtnInstanciar1.Size = new System.Drawing.Size(272, 109);
            this.BtnInstanciar1.TabIndex = 19;
            this.BtnInstanciar1.Text = "Instanciar Mensalista";
            this.BtnInstanciar1.UseVisualStyleBackColor = true;
            this.BtnInstanciar1.Click += new System.EventHandler(this.BtnInstanciar1_Click);
            // 
            // lblEntradaEmpresa
            // 
            this.lblEntradaEmpresa.AutoSize = true;
            this.lblEntradaEmpresa.Location = new System.Drawing.Point(159, 297);
            this.lblEntradaEmpresa.Name = "lblEntradaEmpresa";
            this.lblEntradaEmpresa.Size = new System.Drawing.Size(129, 13);
            this.lblEntradaEmpresa.TabIndex = 18;
            this.lblEntradaEmpresa.Text = "Data Entrada na Empresa";
            this.lblEntradaEmpresa.Click += new System.EventHandler(this.lblEntradaEmpresa_Click);
            // 
            // LblSalarioMensal
            // 
            this.LblSalarioMensal.AutoSize = true;
            this.LblSalarioMensal.Location = new System.Drawing.Point(159, 241);
            this.LblSalarioMensal.Name = "LblSalarioMensal";
            this.LblSalarioMensal.Size = new System.Drawing.Size(76, 13);
            this.LblSalarioMensal.TabIndex = 17;
            this.LblSalarioMensal.Text = "Salário Mensal";
            this.LblSalarioMensal.Click += new System.EventHandler(this.LblSalarioMensal_Click);
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(159, 185);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(35, 13);
            this.lblNome.TabIndex = 16;
            this.lblNome.Text = "Nome";
            this.lblNome.Click += new System.EventHandler(this.lblNome_Click);
            // 
            // LblMatricula
            // 
            this.LblMatricula.AutoSize = true;
            this.LblMatricula.Location = new System.Drawing.Point(159, 134);
            this.LblMatricula.Name = "LblMatricula";
            this.LblMatricula.Size = new System.Drawing.Size(50, 13);
            this.LblMatricula.TabIndex = 15;
            this.LblMatricula.Text = "Mátricula";
            this.LblMatricula.Click += new System.EventHandler(this.LblMatricula_Click);
            // 
            // txtData
            // 
            this.txtData.Location = new System.Drawing.Point(378, 290);
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(125, 20);
            this.txtData.TabIndex = 14;
            this.txtData.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            // 
            // txtSalarioMensal
            // 
            this.txtSalarioMensal.Location = new System.Drawing.Point(378, 234);
            this.txtSalarioMensal.Name = "txtSalarioMensal";
            this.txtSalarioMensal.Size = new System.Drawing.Size(125, 20);
            this.txtSalarioMensal.TabIndex = 13;
            this.txtSalarioMensal.TextChanged += new System.EventHandler(this.txtSalarioMensal_TextChanged);
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(378, 178);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(125, 20);
            this.txtNome.TabIndex = 12;
            this.txtNome.TextChanged += new System.EventHandler(this.txtNome_TextChanged);
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(378, 127);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(125, 20);
            this.txtMatricula.TabIndex = 11;
            this.txtMatricula.TextChanged += new System.EventHandler(this.txtMatricula_TextChanged);
            // 
            // frmMensal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1049, 604);
            this.Controls.Add(this.GbxHomeOffice);
            this.Controls.Add(this.BtnInstanciar2);
            this.Controls.Add(this.BtnInstanciar1);
            this.Controls.Add(this.lblEntradaEmpresa);
            this.Controls.Add(this.LblSalarioMensal);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.LblMatricula);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.txtSalarioMensal);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Name = "frmMensal";
            this.Text = "frmMensal";
            this.GbxHomeOffice.ResumeLayout(false);
            this.GbxHomeOffice.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox GbxHomeOffice;
        private System.Windows.Forms.RadioButton Rbtnao;
        private System.Windows.Forms.RadioButton RbtSim;
        private System.Windows.Forms.Button BtnInstanciar2;
        private System.Windows.Forms.Button BtnInstanciar1;
        private System.Windows.Forms.Label lblEntradaEmpresa;
        private System.Windows.Forms.Label LblSalarioMensal;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label LblMatricula;
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.TextBox txtSalarioMensal;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtMatricula;
    }
}