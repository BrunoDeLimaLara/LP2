﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class FrmHorista : Form
    {
        public FrmHorista()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnInstanciarHorista_Click(object sender, EventArgs e)
        {
            // instanciando o objeto da classe horista
            Horista objHorista = new Horista();

            //set - atribui valores para o objeto

            objHorista.NomeEmpregado = txtNome.Text;
            objHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objHorista.SalarioHora = Convert.ToDouble(txtSalario.Text);
            objHorista.NumeroHora = Convert.ToDouble(txtNumeroDeHoras.Text);
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtDataEntradaEmpresa.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtDiasDeFaltas.Text);
            if (RbtSim.Checked)
                objHorista.HomeOffice = 'S';
            else
                objHorista.HomeOffice = 'N';
            //get - imprime os valores do Objeto
            MessageBox.Show("Nome: " + objHorista.NomeEmpregado + "/n" + 
                "Matricula: " + objHorista.Matricula + "/n" + 
                "Tempo Trabalho(dias); " + objHorista.TempoTrabalho().ToString() + "/n" + 
                "Salário" + objHorista.SalarioBruno().ToString("N2") + "/n" + objHorista.VerificaHome());
        }
    }
}
