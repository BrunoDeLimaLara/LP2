﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication2
{
    class Horista : Empregado
        // não posso herdar mais de uma classe não existe herança múltipla
    {
        //prop e 2x tab croa a estritira da propeiedade
        public double SalarioHora { get; set; }
        public double NumeroHora { get; set; }
        public int DiasFalta { get; set; }

        public override double SalarioBruno()
        {
            return (SalarioHora * NumeroHora);
        }
        //Override indica sobreescreve
        public override int TempoTrabalho()
        {
            //objeto metodo retonra um tipo Span
            TimeSpan span = DateTime.Today.Subtract(DataEntradaEmpresa);
           // return (Convert.ToInt32(span.Days - DiasFalta));
            return (span.Days - DiasFalta);        
        }
    }
}
