﻿namespace WindowsFormsApplication2
{
    partial class FrmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtSalarioHora = new System.Windows.Forms.TextBox();
            this.txtNumeroDeHoras = new System.Windows.Forms.TextBox();
            this.txtDiasDeFaltas = new System.Windows.Forms.TextBox();
            this.txtDataEntradaEmpresa = new System.Windows.Forms.TextBox();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalarioPorHora = new System.Windows.Forms.Label();
            this.lblNumeroDeHoras = new System.Windows.Forms.Label();
            this.lblDataEntradaEmpresa = new System.Windows.Forms.Label();
            this.lblDiasDeFaltas = new System.Windows.Forms.Label();
            this.btnInstanciarHorista = new System.Windows.Forms.Button();
            this.gbxHomeOffice = new System.Windows.Forms.GroupBox();
            this.RbtSim = new System.Windows.Forms.RadioButton();
            this.RbtNão = new System.Windows.Forms.RadioButton();
            this.gbxHomeOffice.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(233, 38);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(100, 20);
            this.txtMatricula.TabIndex = 0;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(233, 87);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 20);
            this.txtNome.TabIndex = 1;
            // 
            // txtSalarioHora
            // 
            this.txtSalarioHora.Location = new System.Drawing.Point(233, 132);
            this.txtSalarioHora.Name = "txtSalarioHora";
            this.txtSalarioHora.Size = new System.Drawing.Size(100, 20);
            this.txtSalarioHora.TabIndex = 2;
            // 
            // txtNumeroDeHoras
            // 
            this.txtNumeroDeHoras.Location = new System.Drawing.Point(233, 176);
            this.txtNumeroDeHoras.Name = "txtNumeroDeHoras";
            this.txtNumeroDeHoras.Size = new System.Drawing.Size(100, 20);
            this.txtNumeroDeHoras.TabIndex = 3;
            // 
            // txtDiasDeFaltas
            // 
            this.txtDiasDeFaltas.Location = new System.Drawing.Point(233, 258);
            this.txtDiasDeFaltas.Name = "txtDiasDeFaltas";
            this.txtDiasDeFaltas.Size = new System.Drawing.Size(100, 20);
            this.txtDiasDeFaltas.TabIndex = 4;
            // 
            // txtDataEntradaEmpresa
            // 
            this.txtDataEntradaEmpresa.Location = new System.Drawing.Point(233, 217);
            this.txtDataEntradaEmpresa.Name = "txtDataEntradaEmpresa";
            this.txtDataEntradaEmpresa.Size = new System.Drawing.Size(100, 20);
            this.txtDataEntradaEmpresa.TabIndex = 5;
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Location = new System.Drawing.Point(90, 45);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(50, 13);
            this.lblMatricula.TabIndex = 6;
            this.lblMatricula.Text = "Matricula";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(90, 90);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(35, 13);
            this.lblNome.TabIndex = 7;
            this.lblNome.Text = "Nome";
            // 
            // lblSalarioPorHora
            // 
            this.lblSalarioPorHora.AutoSize = true;
            this.lblSalarioPorHora.Location = new System.Drawing.Point(90, 139);
            this.lblSalarioPorHora.Name = "lblSalarioPorHora";
            this.lblSalarioPorHora.Size = new System.Drawing.Size(83, 13);
            this.lblSalarioPorHora.TabIndex = 8;
            this.lblSalarioPorHora.Text = "Salário por Hora";
            // 
            // lblNumeroDeHoras
            // 
            this.lblNumeroDeHoras.AutoSize = true;
            this.lblNumeroDeHoras.Location = new System.Drawing.Point(90, 183);
            this.lblNumeroDeHoras.Name = "lblNumeroDeHoras";
            this.lblNumeroDeHoras.Size = new System.Drawing.Size(90, 13);
            this.lblNumeroDeHoras.TabIndex = 9;
            this.lblNumeroDeHoras.Text = "Número de Horas";
            // 
            // lblDataEntradaEmpresa
            // 
            this.lblDataEntradaEmpresa.AutoSize = true;
            this.lblDataEntradaEmpresa.Location = new System.Drawing.Point(90, 224);
            this.lblDataEntradaEmpresa.Name = "lblDataEntradaEmpresa";
            this.lblDataEntradaEmpresa.Size = new System.Drawing.Size(129, 13);
            this.lblDataEntradaEmpresa.TabIndex = 10;
            this.lblDataEntradaEmpresa.Text = "Data Entrada na Empresa";
            // 
            // lblDiasDeFaltas
            // 
            this.lblDiasDeFaltas.AutoSize = true;
            this.lblDiasDeFaltas.Location = new System.Drawing.Point(90, 265);
            this.lblDiasDeFaltas.Name = "lblDiasDeFaltas";
            this.lblDiasDeFaltas.Size = new System.Drawing.Size(71, 13);
            this.lblDiasDeFaltas.TabIndex = 11;
            this.lblDiasDeFaltas.Text = "Dias de faltas";
            // 
            // btnInstanciarHorista
            // 
            this.btnInstanciarHorista.Location = new System.Drawing.Point(124, 330);
            this.btnInstanciarHorista.Name = "btnInstanciarHorista";
            this.btnInstanciarHorista.Size = new System.Drawing.Size(242, 58);
            this.btnInstanciarHorista.TabIndex = 12;
            this.btnInstanciarHorista.Text = "Instanciar Horista";
            this.btnInstanciarHorista.UseVisualStyleBackColor = true;
            this.btnInstanciarHorista.Click += new System.EventHandler(this.btnInstanciarHorista_Click);
            // 
            // gbxHomeOffice
            // 
            this.gbxHomeOffice.Controls.Add(this.RbtNão);
            this.gbxHomeOffice.Controls.Add(this.RbtSim);
            this.gbxHomeOffice.Location = new System.Drawing.Point(407, 52);
            this.gbxHomeOffice.Name = "gbxHomeOffice";
            this.gbxHomeOffice.Size = new System.Drawing.Size(200, 100);
            this.gbxHomeOffice.TabIndex = 13;
            this.gbxHomeOffice.TabStop = false;
            this.gbxHomeOffice.Text = "Trabalhou em Home Oficce";
            // 
            // RbtSim
            // 
            this.RbtSim.AutoSize = true;
            this.RbtSim.Location = new System.Drawing.Point(0, 32);
            this.RbtSim.Name = "RbtSim";
            this.RbtSim.Size = new System.Drawing.Size(42, 17);
            this.RbtSim.TabIndex = 0;
            this.RbtSim.TabStop = true;
            this.RbtSim.Text = "Sim";
            this.RbtSim.UseVisualStyleBackColor = true;
            this.RbtSim.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // RbtNão
            // 
            this.RbtNão.AutoSize = true;
            this.RbtNão.Location = new System.Drawing.Point(0, 55);
            this.RbtNão.Name = "RbtNão";
            this.RbtNão.Size = new System.Drawing.Size(45, 17);
            this.RbtNão.TabIndex = 1;
            this.RbtNão.TabStop = true;
            this.RbtNão.Text = "Não";
            this.RbtNão.UseVisualStyleBackColor = true;
            // 
            // FrmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(642, 427);
            this.Controls.Add(this.gbxHomeOffice);
            this.Controls.Add(this.btnInstanciarHorista);
            this.Controls.Add(this.lblDiasDeFaltas);
            this.Controls.Add(this.lblDataEntradaEmpresa);
            this.Controls.Add(this.lblNumeroDeHoras);
            this.Controls.Add(this.lblSalarioPorHora);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMatricula);
            this.Controls.Add(this.txtDataEntradaEmpresa);
            this.Controls.Add(this.txtDiasDeFaltas);
            this.Controls.Add(this.txtNumeroDeHoras);
            this.Controls.Add(this.txtSalarioHora);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Name = "FrmHorista";
            this.Text = "FrmHorista";
            this.gbxHomeOffice.ResumeLayout(false);
            this.gbxHomeOffice.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtSalarioHora;
        private System.Windows.Forms.TextBox txtNumeroDeHoras;
        private System.Windows.Forms.TextBox txtDiasDeFaltas;
        private System.Windows.Forms.TextBox txtDataEntradaEmpresa;
        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalarioPorHora;
        private System.Windows.Forms.Label lblNumeroDeHoras;
        private System.Windows.Forms.Label lblDataEntradaEmpresa;
        private System.Windows.Forms.Label lblDiasDeFaltas;
        private System.Windows.Forms.Button btnInstanciarHorista;
        private System.Windows.Forms.GroupBox gbxHomeOffice;
        private System.Windows.Forms.RadioButton RbtNão;
        private System.Windows.Forms.RadioButton RbtSim;
    }
}