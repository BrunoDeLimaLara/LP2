﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class frmMensal : Form
    {
        public frmMensal()
        {
            InitializeComponent();
        }

        private void BtnInstanciar1_Click(object sender, EventArgs e)
        {

            Mensalista objMensalista = new Mensalista(); // criar ou instanciar o objeto da classe horista

            //set
            objMensalista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objMensalista.NomeEmpregado = txtNome.Text;
            objMensalista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);
            objMensalista.SalarioMensal = Convert.ToDouble(txtSalarioMensal.Text);

            if (RbtSim.Checked)
                objMensalista.HomeOffice = 'S';
            else
                objMensalista.HomeOffice = 'N';

            //get

            MessageBox.Show("Matricula: " + objMensalista.Matricula + "/n" +
                "Nome: " + objMensalista.NomeEmpregado + "/n" +
                "Data Emdrada: " + objMensalista.DataEntradaEmpresa.ToString("n2") + "/n" +
                "Salário Bruto:" + objMensalista.SalarioBruno().ToString("N2") + "/n" +
                "Tempo EMpresa(dias): " + objMensalista.TempoTrabalho() + "/n" + objMensalista.VerificaHome());
        }

        private void BtnInstanciar2_Click(object sender, EventArgs e)
        {

        }

        private void GbxHomeOffice_Enter(object sender, EventArgs e)
        {

        }

        private void lblEntradaEmpresa_Click(object sender, EventArgs e)
        {

        }

        private void LblSalarioMensal_Click(object sender, EventArgs e)
        {

        }

        private void lblNome_Click(object sender, EventArgs e)
        {

        }

        private void LblMatricula_Click(object sender, EventArgs e)
        {

        }

        private void txtData_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtSalarioMensal_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNome_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtMatricula_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
