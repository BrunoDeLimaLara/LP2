﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication2
{
    class Mensalista :Empregado // especializaçãp -> herança(referencia a origem)
    {
        public Double SalarioMensal{ get; set; }
    //sobrescrevendo o método
        
        public override double SalarioBruno()
        {
            return SalarioMensal;  
        }
    }

}
