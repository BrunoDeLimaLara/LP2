﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmenus
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            int resultado, num1, num2;
            Random Sorteio = new Random();

            if (String.IsNullOrEmpty(txtNumero1.Text) || String.IsNullOrEmpty(txtNumero2.Text))
            {
                MessageBox.Show("Informe os Valores Primeiro!");
            }
            else
            {
                if (Int32.TryParse(txtNumero1.Text, out num1) && Int32.TryParse(txtNumero2.Text, out num2))
                {
                    if (num1 > num2)
                    {
                        MessageBox.Show("O Primeiro Número deve ser Menor ou Igual ao Segundo Número!");
                    }
                    else 
                    {
                        resultado = Sorteio.Next(num1, num2);

                        MessageBox.Show("O Número Sorteado Foi: " + Convert.ToString(resultado));
                    }
                }
                else 
                {
                    MessageBox.Show("Valores Inválidos!");
                }
            }
        }
    }
}
