﻿namespace Pmenus
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rctxtStringao = new System.Windows.Forms.RichTextBox();
            this.btnQntdNumericos = new System.Windows.Forms.Button();
            this.btnPosicaoBranco = new System.Windows.Forms.Button();
            this.btnQntdAlfabeticos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rctxtStringao
            // 
            this.rctxtStringao.Location = new System.Drawing.Point(30, 27);
            this.rctxtStringao.Name = "rctxtStringao";
            this.rctxtStringao.Size = new System.Drawing.Size(460, 196);
            this.rctxtStringao.TabIndex = 0;
            this.rctxtStringao.Text = "";
            // 
            // btnQntdNumericos
            // 
            this.btnQntdNumericos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQntdNumericos.Location = new System.Drawing.Point(65, 252);
            this.btnQntdNumericos.Name = "btnQntdNumericos";
            this.btnQntdNumericos.Size = new System.Drawing.Size(102, 71);
            this.btnQntdNumericos.TabIndex = 1;
            this.btnQntdNumericos.Text = "Quantidade de Caracteres Númericos";
            this.btnQntdNumericos.UseVisualStyleBackColor = true;
            this.btnQntdNumericos.Click += new System.EventHandler(this.btnQntdNumericos_Click);
            // 
            // btnPosicaoBranco
            // 
            this.btnPosicaoBranco.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPosicaoBranco.Location = new System.Drawing.Point(201, 252);
            this.btnPosicaoBranco.Name = "btnPosicaoBranco";
            this.btnPosicaoBranco.Size = new System.Drawing.Size(102, 71);
            this.btnPosicaoBranco.TabIndex = 2;
            this.btnPosicaoBranco.Text = "Posição do Primeiro Caracter em Branco";
            this.btnPosicaoBranco.UseVisualStyleBackColor = true;
            this.btnPosicaoBranco.Click += new System.EventHandler(this.btnPosicaoBranco_Click);
            // 
            // btnQntdAlfabeticos
            // 
            this.btnQntdAlfabeticos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQntdAlfabeticos.Location = new System.Drawing.Point(340, 252);
            this.btnQntdAlfabeticos.Name = "btnQntdAlfabeticos";
            this.btnQntdAlfabeticos.Size = new System.Drawing.Size(102, 71);
            this.btnQntdAlfabeticos.TabIndex = 3;
            this.btnQntdAlfabeticos.Text = "Quantidade de Caracteres Alfabéticos";
            this.btnQntdAlfabeticos.UseVisualStyleBackColor = true;
            this.btnQntdAlfabeticos.Click += new System.EventHandler(this.btnQntdAlfabeticos_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(522, 440);
            this.Controls.Add(this.btnQntdAlfabeticos);
            this.Controls.Add(this.btnPosicaoBranco);
            this.Controls.Add(this.btnQntdNumericos);
            this.Controls.Add(this.rctxtStringao);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rctxtStringao;
        private System.Windows.Forms.Button btnQntdNumericos;
        private System.Windows.Forms.Button btnPosicaoBranco;
        private System.Windows.Forms.Button btnQntdAlfabeticos;
    }
}