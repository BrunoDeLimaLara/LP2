﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmenus
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnQntdNumericos_Click(object sender, EventArgs e)
        {
            int i, qntdNumeros, Stringao;
            string Strinome;

            qntdNumeros = 0;
            Strinome = rctxtStringao.Text;
            Stringao = rctxtStringao.Text.Length;

            for (i = 0; i < Stringao; i++) 
            {
                if (Char.IsNumber(Strinome[i]))
                {
                    qntdNumeros += 1;
                }
            }

            MessageBox.Show("A Quantidade de Caracteres Númericos é: " + Convert.ToString(qntdNumeros));
        }

        private void btnPosicaoBranco_Click(object sender, EventArgs e)
        {
            int i, Stringao;
            string Strinome;
            bool achou;

            achou = false;
            Strinome = rctxtStringao.Text;
            Stringao = rctxtStringao.Text.Length;

            i = 0;
            while (i < Stringao)
            {
                if (Char.IsWhiteSpace(Strinome[i]))
                {
                    MessageBox.Show("A Posição do Primeiro Caractere em Branco é: " + Convert.ToString(i));
                    achou = true;
                    break;
                }

                i++; // NUNCA! Esqueça o incremento manual em uma estrutura de repetição while.
            }

            if (achou == false)
            { 
                MessageBox.Show("Não foi encontrado nenhum Espaço em Branco");
            }
        }

        private void btnQntdAlfabeticos_Click(object sender, EventArgs e)
        {
            int i, qntdLetras;
            string Strinome;

            i = 0;
            qntdLetras = 0;
            Strinome = rctxtStringao.Text;

            foreach (var Letra in Strinome) 
            {
                if (Char.IsLetter(Strinome[i]))
                {
                    qntdLetras += 1;
                }
                i++;
            }

            MessageBox.Show("A Quantidade de Caracteres Alfabéticos é: " + Convert.ToString(qntdLetras));
        }
    }
}
