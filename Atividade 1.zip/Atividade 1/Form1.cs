﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ex1PVolume
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            double Raio, Altura;

            if (Double.TryParse(TxtAltura.Text, out Altura) &&
                Double.TryParse(TxtRaio.Text, out Raio))
            { 
                if ((Altura <= 0) || (Raio <= 0))
                {
                    MessageBox.Show("Altura e raio devem ser maiores que zero");
                        TxtRaio.Focus();
                }
                else
                {
                    double volume;
                    volume = Math.PI * Math.Pow(Raio, 2) * Altura;
                    TxtVolume.Text = volume.ToString("N2");
                }
            }
            else
            {
                MessageBox.Show("valores Invalidos");
                TxtRaio.Focus();
            }
        }

        private void BtnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            TxtAltura.Clear();
            TxtRaio.Text = "";
            TxtVolume.Text = string.Empty;

            TxtRaio.Focus();
        }

        private void TxtRaio_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtRaio_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (Char)13)
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }

        }
    }
}
